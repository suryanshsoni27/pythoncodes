# SoftwareProcessOthello
othello microservice
