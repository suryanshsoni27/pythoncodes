'''
     Created on April 20 2020
    
    @author:  Suryansh Soni
'''
import othello.status as st
import othello.create as cr
import random
from math import sqrt
import hashlib
from othello.status import Parameter

def _checkIfTokenALreaadyOnBoard(parms):
    None


def _combineStatusForPlace(parms):
    dicToReturn = {}
    try:
        status = _statusUpdate(parms)
        board,token = _placeOnBoard(parms)
        integrity = _returnIntegirty(parms)
        dicToReturn.update({'board':board,'integrity':integrity,'status':status})
    except:
        dicToReturn = {'error':'something went wrong [check your parameter, all unique value for tokens, valid location , valid board and correct integrity'}  
          
    if(dicToReturn == {'board':{'status': 'location not valid'}, 'integrity': 'cannot give integrity', 'status': {'status': 'error occurred check your parameter'}}):
        
        dicToReturn = {'error':'location not valid'}
        
    return dicToReturn

def _changeStatusForEnd(parms):
    lightcount = 0
    darkcount = 0
    parms = st.Parameter(**parms)
    board = st._convertBoard(parms.board)
    for el in board:
        if el == parms.light:
            lightcount = lightcount + 1
        elif el == parms.dark:
            darkcount = darkcount + 1
    
    conStr = "end:" + str(lightcount) + "/" + str(darkcount)
    status = conStr
    return status

def _statusUpdate(parms):
    if(_whatIsStatusofParm(parms) == {'status':'ok'} or _whatIsStatusofParm(parms) == {'status':'light'} or _whatIsStatusofParm(parms) == {'status':'dark'}):
        status = 'ok'
    elif(_whatIsStatusofParm(parms) == {'status':'end'}):
        status = _changeStatusForEnd(parms)
    else:
        status = {'status':'error occurred check your parameter'}         
    return status      
    
def _hexGenforPlace(parms, columwise, tok):
    hashString = ""
    for el in columwise:
        hashString += str(el)
    
    hashString = hashString + "/" + str(parms.light) + "/" + str(parms.dark) + "/" + str(parms.blank) + "/" + str(tok)
    integrityReturned = hashlib.sha256(hashString.encode('utf-8')).hexdigest()
    return integrityReturned
  
def _seeNext(parms):
    nexttok = st._statusCheck(parms)    
    return(nexttok)
    
def _returnIntegirty(parms):
    parms_fo = parms
    parms_dup = parms
    parms_if = parms 
    integrityReturned = ""
    parms_fo = st.Parameter(**parms_fo)    
    res2 = st._hexGen(parms_fo,parms_fo.light)
    res1 = st._hexGen(parms_fo,parms_fo.dark) 
    if(_whatIsStatusofParm(parms) == {'status':'ok'}):
        board,token = _placeOnBoard(parms)
        if(board == {'status':'location not valid'} or token == 0):
            integrityReturned = 'cannot give integrity'
        else: 
            columwise = st._boardColumnWiseGen(board) 
            parms_dup['board'] = board
            tok = _seeNext(parms_dup) 
            parms_if = st.Parameter(**parms_if) 
            if(token == parms_if.light):   
                tok = _seeNext(parms_if)
                if(tok == {'status': 'ok'}):
                    tok = parms_if.dark
                elif(tok == {'status':'light'}):
                    tok = parms_if.light  
                parms_dup = st.Parameter(**parms_dup)      
                rese1 = _hexGenforPlace(parms_dup, columwise, tok)   
            elif(token == parms_if.dark):
                tok = _seeNext(parms_if)
                if(tok == {'status':'ok'}):
                    tok = parms_if.light
                elif(tok == {'status':'dark'}):
                    tok = parms_if.dark 
                parms_dup = st.Parameter(**parms_dup)    
                rese2 = _hexGenforPlace(parms_dup, columwise, tok)
                
            parms = st.Parameter(**parms)
            if(parms_fo.integrity == res1):
                integrityReturned= rese2
            elif(parms_fo.integrity == res2):
                integrityReturned = rese1         
    elif(_whatIsStatusofParm(parms) == {'status':'light'}):
        board,token = _placeOnBoard(parms)
        if(board == {'status':'location not valid'} or token == 0):
            integrityReturned = 'cannot give integrity'
        else:    
            columwise = st._boardColumnWiseGen(board)  
            parms['board'] = board
            parms = st.Parameter(**parms)
            tok = parms.dark
            integrityReturned = _hexGenforPlace(parms, columwise, tok)      
    elif(_whatIsStatusofParm(parms) == {'status':'dark'}):
        board,token = _placeOnBoard(parms) 
        if(board == {'status':'location not valid'} or token == 0):
            integrityReturned = 'cannot give integrity'
        else:
            columwise = st._boardColumnWiseGen(board)  
            parms = st.Parameter(**parms)
            tok = parms.light
            integrityReturned = _hexGenforPlace(parms, columwise, tok)      
    elif(_whatIsStatusofParm(parms) == {'status':'end'}): 
        parms = st.Parameter(**parms)
        board = st._convertBoard(parms.board) 
        columwise = st._boardColumnWiseGen(board) 
        tok = parms.dark 
        integrityReturned = _hexGenforPlace(parms, columwise, tok)
    
    elif(_whatIsStatusofParm(parms) == {'status':'location not valid'}):
        board,token = _placeOnBoard(parms) 
        if(board == {'status':'location not valid'} or token == 0):
            integrityReturned = 'cannot give integrity'
              
    return integrityReturned
            
             


def _removeColon(location):
    newloc = []
    i = 1
    newloc = location.split(':')
    return newloc

def _checkIfAllint(stringcheck, newloc):
    for x in newloc:
        try:
            int(x)
            result = 1
            stringcheck.append(result)
        except ValueError:
            result = 0
            stringcheck.append(result)

def _getResult(sum, stringcheck):
    for i in stringcheck:
        sum = sum + i
    if (sum == 2):
        result = True
    else:
        result = False
    return result

def _ischeckLocationValid(parms):
    parms = st.Parameter(**parms)
    location = parms.location
    sum = 0
    stringcheck = [] 
    newloc = ""
    newloc = _removeColon(location)   
    _checkIfAllint(stringcheck, newloc)            
    result = _getResult(sum, stringcheck) 
    return result        
                                              
def _matchingTokenForTheGivenHex(parms):
    res1 = st._hexGen(parms, parms.dark)
    res2 = st._hexGen(parms, parms.light)
    if (parms.integrity == res1):
        token = parms.dark
    elif (parms.integrity == res2):
        token = parms.light
    return token

def _getMydefaults(parms):
    board = st._convertBoard(parms.board)
    #token = random.choice([parms.light, parms.dark])
    token = _matchingTokenForTheGivenHex(parms)    
    location = parms.location
    liLoc = []
    liLoc = _removeColon(location)
    row = int(liLoc[0])
    col = int(liLoc[1])
    size = int(sqrt(len(board)))
    return board, size, token, row, col


def _getMy2Dboard(size, board2D, boarditr):
    for i in range(size):
        arr2 = []
        for j in range(size):
            arr2.append(next(boarditr))
        board2D.append(arr2)
    return i, j


def _puttingTokenInBoard(board, token, row, col, board2D, i, j):
    for i in range(int(sqrt(len(board)))):
        for j in range(int(sqrt(len(board)))):
            if (i == row and j == col):
                board2D[row][col] = token
    boar = []
    for i in range(int(sqrt(len(board)))):
        for j in range(int(sqrt(len(board)))):
            boar.append(board2D[i][j])
    return boar

def _placeOnBoard(parms):
    if(_whatIsStatusofParm(parms) == {'status':'ok'}):
        parms = st.Parameter(**parms)
        board, size, token, row, col = _getMydefaults(parms)
        board2D = []
        boarditr = iter(board)
        i, j = _getMy2Dboard(size, board2D, boarditr)
        if(token == parms.light):
            boar = _puttingTokenInBoard(board, token, row, col, board2D, i, j)                       
        elif(token == parms.dark):
            boar = _puttingTokenInBoard(board, token, row, col, board2D, i, j) 
        return boar,token        
    elif(_whatIsStatusofParm(parms) == {'status':'light'}): 
        parms = st.Parameter(**parms)
        board, size, token, row, col = _getMydefaults(parms)
        board2D = []
        boarditr = iter(board)
        i, j = _getMy2Dboard(size, board2D, boarditr)
        if(token == parms.light):
            boar = _puttingTokenInBoard(board, token, row, col, board2D, i, j)                       
        return boar,token    
    elif(_whatIsStatusofParm(parms) == {'status':'dark'}):
        parms = st.Parameter(**parms) 
        board, size, token, row, col = _getMydefaults(parms)
        board2D = []
        boarditr = iter(board)
        i, j = _getMy2Dboard(size, board2D, boarditr)
        if(token == parms.dark):
            boar = _puttingTokenInBoard(board, token, row, col, board2D, i, j)                        
        return boar,token 
        
    elif(_whatIsStatusofParm(parms) == {'status':'end'}):
        board = st._convertBoard(parms.board)
        return board,parms.dark
    elif(_whatIsStatusofParm(parms) == {'status':'location not valid'}):
        return _whatIsStatusofParm(parms),0     
             

def _whatIsStatusofParm(parms):
    if(_ischeckLocationValid(parms)):
        return st._status(parms)
    else:
        return {'status':'location not valid'}


def _playNext(parms):
    parms = st.Parameter(**parms)
    location = parms.location
    return location
    
    


def _place(parms):
    result = {'status': 'place stub'}
    if(parms == {}):
        result =  {'status':'error: Nothing has been passed'}
    else:
        result = _combineStatusForPlace(parms)
    
    return result
