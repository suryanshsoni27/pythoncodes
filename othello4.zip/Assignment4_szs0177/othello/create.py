'''
     Created on March 8 2020
    
    @author:    Suryansh Soni
'''

import hashlib


board_default = {    
'board': [0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0, 0,0,0,1,2,0,0,0, 0,0,0,2,1,0,0,0, 0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0],
'tokens':{'light':1,'dark':2, 'blank':0},
'status':'ok',
'integrity':'b11fcf5f9ac9d3b8cea8085208e210182a8d6b73a84028562ab2c87d190b9ada'
} 


#This returns the board
#Here fac1, fac2, fac3 are factors that are being used to calculate correct board length and positions for the light dark and blanks

def _boardReturn(parm_size,light,dark,blank):
    board = []
    fac1,fac2,fac3 = _returnFactor(parm_size)
    size = parm_size*parm_size
    for i in range(1,size+1):
        if(i == size/2 - fac1):
            board.append(light) 
        elif(i == size/2 + fac1):
            board.append(dark)    
        elif(i == size/2 -fac2):
            board.append(dark) 
        elif(i == size/2 + fac3):
            board.append(light)  
        else:
            board.append(blank)   
    return board 



#Returns the factor required for finding correct board  
def _returnFactor(given_size):
    if(given_size == 6):
        return 3,2,4
    elif(given_size == 8):
        return 4,3,5
    elif(given_size == 10):
        return 5,4,6
    elif(given_size == 12):
        return 6,5,7
    elif(given_size == 14):
        return 7,6,8
    elif(given_size == 16):
        return 8,7,9  
    
    
     
    
#Generates the sha256 hexdigest value
def _hexdigestGenerator(parms, result):
    hashString = ""
    for el in result['board']:
        hashString += str(el)
        
    hashString = hashString + "/" + str(parms['light']) + "/" + str(parms['dark']) + "/" + str(parms['blank']) + "/" + str(parms['dark'])
    result['integrity'] = hashlib.sha256(hashString.encode('utf-8')).hexdigest()




#Gives the valid board 
def _validBoard(parms, result):
    if(parms['size'] in range(6,18,2)):
        result['board'] = _boardReturn(parms['size'], parms['light'], parms['dark'], parms['blank'])
    else:
        result = {'status':'error:board value not valid'}
    return result



                    
#Extracts the final result
def _extractResult(parms, result):
    result = {
        'board':None, 
        'tokens':None, 
        'status':None, 
        'integrity':None}
    result['tokens'] = {'light':parms['light'], 'dark':parms['dark'], 'blank':parms['blank']}
    result['status'] = 'ok'
    result = _validBoard(parms, result)
    return result




#Not supplied and extra parameter checking and removal
def _noSupply_extragenousParmCheck(parms):
    required_dict = {'light':None, 'dark':None, 'blank':None, 'size':None}
    for key in parms.keys():
        if not key in required_dict:
            parms.pop('key', None)    
    for key in required_dict.keys():
        if not 'light' in parms:
            parms.update({'light':1})
        if not 'dark' in parms:
            parms.update({'dark':2})
        if not 'blank' in parms:
            parms.update({'blank':0})
        if not 'size' in parms:
            parms.update({'size':8})   
            
            
              
#Checks if the parameter in the range or not
def _isRangeCheck(parms):
    if (parms['light']  not in list(range(0, 10))):
        return True
    elif (parms['dark']  not in list(range(0, 10))):
        return True
    elif (parms['blank']  not in list(range(0, 10))):
        return True
    
    
    
    
#Checks if the parameters are same 
def _isSameParamCheck(parms):
    return(parms['light'] == parms['dark'] or parms['light'] == parms['blank'] or parms['blank'] == parms['dark'])
    
    
    
    
#Converts parameter               
def _convertParm(parms):
    for key in parms.keys():
        if parms[key] == None:
            parms[key] = parms[key] 
            
        elif type(parms[key]) == int:
            try: 
                parms[key] = int(parms[key])
            except:
                parms[key] = parms[key]           
                   
        elif parms[key].isdigit():
            try: 
                parms[key] = int(parms[key])
            except:
                parms[key] = parms[key]           
        else:
            try: 
                parms[key] = float(parms[key])
            except:
                parms[key] = parms[key]  
                
                
                
            
#Empty parameter checking
def _isEmptyParmCheck(parms):
    return parms['light'] == '' or parms['dark'] == '' or parms['blank'] == '' or parms['size'] == ''


 
 
#Main create function
def _create(parms):    
    result = {'create': 'create stub'} 
    _convertParm(parms)        
    _noSupply_extragenousParmCheck(parms)
    if(parms == {} or parms == {'light':1, 'dark':2, 'blank':0, 'size':8}): 
        result = board_default
    elif _isRangeCheck(parms) or _isEmptyParmCheck(parms):
        result = {'status':'error: not in range'}  
    elif _isSameParamCheck(parms):
        result = {'status':'error: same parameters passed'}                        
    else:
        result = _extractResult(parms, result) 
        if(result == {'status':'error:board value not valid'}):
            return result        
        _hexdigestGenerator(parms, result)                                                            
    return(result)




    
    





    





