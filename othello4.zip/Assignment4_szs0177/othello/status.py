'''
     Created on March 21 2020
    
    @author:    Suryansh Soni
'''



import othello.create as cr
import hashlib
from math import sqrt
#class that converts incoming parameter from dictionary to class objects
class Parameter:
    def __init__(self,**entries):
            self.__dict__.update(entries)
            
#updates the parameter             
def _updateParms(parms):
    required_dict = {'light':None, 'dark':None, 'blank':None, 'board':None, 'integrity':None}
    for key in parms.keys():
        if not key in required_dict:
            parms.pop('key', None)
    for key in required_dict.keys():
        if not 'light' in parms:
            parms.update({'light':1})
        if not 'dark' in parms:
            parms.update({'dark':2})
        if not 'blank' in parms:
            parms.update({'blank':0})
        if not 'board' in parms:
            parms.update({'board':""})
        if not 'integrity' in parms:
            parms.update({'integrity':""}) 
                   
#converts the board from string to normal board            
def _convertBoard(board):
    returnBoard = []
    for i in board:
        if (i != ',' and i != ']' and i != '[' and i!=" "):
            returnBoard.append(int(i)) 
    return returnBoard

#checks Board if the values in that match light dark and blank 
def _ischeckBoardLDB(parms):
    cr._convertParm(parms)
    _updateParms(parms)
    parms = Parameter(**parms)
    board = _convertBoard(parms.board)
    bool_in_Board = True
    validValuesInBoard = [parms.light, parms.dark, parms.blank]
    if (set(validValuesInBoard) == set(board) or len(set(validValuesInBoard)) >= len(set(board))):
        bool_in_Board = True
    else:
        bool_in_Board = False
    return bool_in_Board, board

#checks the board size if ok
def _ischeckBoardSize(bool_in_Board, board):
    listRequired = [36, 64, 100, 144, 196, 256]
    if (bool_in_Board == True):
        if (len(board) in listRequired):
            boolValidBoard = True
        else:
            boolValidBoard = False
    else:
        boolValidBoard = False
    return boolValidBoard

#checks is the board is valid with the given parameter
def _ischeckBoard_valid(parms):
    if(parms['board'] != ""):
        bool_in_Board, board = _ischeckBoardLDB(parms)
        boolValidBoard = _ischeckBoardSize(bool_in_Board, board)
    else:
        boolValidBoard = False    
    return boolValidBoard    

#checks if the hex parameter is valid 
def _ischeckHexValid_byParamter(parms):
    parms = Parameter(**parms) 
    hexpresent = parms.integrity                   
    if(hexpresent == None or hexpresent == " " or len(hexpresent) != 64):
        return False 
    else:
        return True
#checks range of parameters    
def _isRange(parms):
    bool1 = False 
    bool2 = False
    bool3 = False
    cr._convertParm(parms)
    if (parms['light'] not in list(range(0, 10))):
        bool1 = True
    if (parms['dark'] not in list(range(0, 10))):
        bool2 =  True
    if (parms['blank'] not in list(range(0, 10))):
        bool3 = True 
    if(bool1 or bool2 or bool3):
        return False
    else:
        return True 
    
#generates the column wise 
def _boardColumnWiseGen(board):
    columnwise = ""
    for row in range(int(sqrt(len(board)))):
        for col in range(int(sqrt(len(board)))):
            columnwise += str(board[int(sqrt(len(board))) * col + row])       
    return columnwise 

#generates hex value for column wise board 
def _hexGen(parms,tok):
    if not isinstance(parms, Parameter):
        parms = Parameter(**parms)
    else:
        parms = parms
    board = _convertBoard(parms.board)    
    columwise = _boardColumnWiseGen(board)     
    hashString = ""
    for el in columwise:
        hashString += str(el)        
    hashString = hashString + "/" + str(parms.light) + "/" + str(parms.dark) + "/" + str(parms.blank) + "/" + str(tok)
    result = hashlib.sha256(hashString.encode('utf-8')).hexdigest() 
    return result 
  
#checks the parameter    

    
def _parmsCheck(parms):
    _updateParms(parms) 
    isBool = False  
    if(_isRange(parms)):    
        if(cr._isSameParamCheck(parms)):
            isBool = False
        else:
            isBool = True
        if(isBool != False):
            
            if(_ischeckBoard_valid(parms) == True): 
                if(_ischeckHexValid_byParamter(parms)):
                    isBool = True
                else:
                    isBool = False          
            else:
                isBool = False 
                                                                 
    return parms,isBool

#checks if position are available on parms kept for future use                
def _ispositionAvailable(board,parms):
    boolar= []
    if isinstance(parms, Parameter):
        board = _convertBoard(board)
        size = int(len(board))
        for i in range(size):
            if(board[i] == int(parms.blank)):
                boolar.append(i)  
    return boolar    

#checks if the token available in parms kept for future use 
def _ischeckTokenAvailable(board,parms):
    boolar= []
    if isinstance(parms, Parameter):
        light = parms.light
        dark = parms.dark
        board = _convertBoard(board)
        size = int(len(board))
     
        for i in range(size):
            if(board[i] == int(light) or board[i] == int(dark)):
                boolar.append(i)  
    return boolar
  
#Refactored part that checks if the board values that are being traversed exist within the bounds  
def _ispresentBoardOn(size, y, x):
    return x >= 0 and y <= size - 1 and y >= 0 and x <= size - 1

#gives 2d matrix 
def _getMyMatrix(boarditr, size, boardArr):
    for i in range(size):
        arr2 = []
        for j in range(size):
            arr2.append(next(boarditr))
        boardArr.append(arr2)
    return i, j

#checks available blank and occupied blank 
def _availableBlank_occupiedBlank(parms):
    avail = _ispositionAvailable(parms.board, parms)
    availLD = _ischeckTokenAvailable(parms.board, parms)
    return avail, availLD

#changing status of the stat for light and dark test
def _ChangingStatLD(parms, other):
    if (other == int(parms.light)):
        stat = {'status':'dark'}
    elif (other == int(parms.dark)):
        stat = {'status':'light'}
    return stat

#steps up the move 
def _SteppingUp(xd, yd, x, y):
    x = x + xd
    y = y + yd
    return y, x

#gives my default values
def _gettingMyDefaults(parms):
    if isinstance(parms.board,str):
        board = _convertBoard(parms.board)
    else:
        board = parms.board    
    boarditr = iter(board)
    size = int(sqrt(len(board)))
    boardArr = []
    stat = {}
    return boarditr, size, boardArr, stat

#checks the incoming parms are valid form the board
#refactored part from statusCheck
def _performCheckOnIncomingParm(parms):
    if not isinstance(parms, Parameter):
        parms = Parameter(**parms)
    else:
        parms = parms
    boarditr, size, boardArr, stat = _gettingMyDefaults(parms)
    i, j = _getMyMatrix(boarditr, size, boardArr)
    avail, availLD = _availableBlank_occupiedBlank(parms)
    return avail, availLD, i, size, j, boardArr, parms, stat

#performs status check to print the correct values for the 
def _statusCheck(parms):
    direction = [[0, 1], [1, 1], [1, 0], [1, -1], [0, -1], [-1, -1], [-1, 0], [-1, 1]]
    avail, availLD, i, size, j, boardArr, parms, stat = _performCheckOnIncomingParm(parms)        
    if(len(avail) == 0):
        return {'status':'end'}
    if(len(avail) > len(availLD)):
        return {'status':'ok'}
    else:
        for i in range(size):
            for j in range(size):
                tile = boardArr[i][j]
                if(tile == int(parms.light)):
                    other = int(parms.dark)
                elif(tile == int(parms.dark)):
                    other = int(parms.light) 
                else:
                    continue    
                for xd,yd in direction:
                    x = i
                    y = j 
                    y, x = _SteppingUp(xd, yd, x, y)
                    if(_ispresentBoardOn(size, y, x) and boardArr[x][y] == other):
                        y, x = _SteppingUp(xd, yd, x, y)
                        if not _ispresentBoardOn(size, y, x):
                            continue
                        while boardArr[x][y] == other:
                                y, x = _SteppingUp(xd, yd, x, y) 
                                if not _ispresentBoardOn(size, y, x):
                                    break
                                if(boardArr[x][y] == int(parms.blank)):
                                    stat = _ChangingStatLD(parms, other)                                       
                if not _ispresentBoardOn(size, y, x):
                    continue         
        if stat == {}:
            stat = {'status':'end'}           
    return stat    

#updates the result
def _calculateResult(parms, result):
    res1 = _hexGen(parms, parms.dark)
    res2 = _hexGen(parms, parms.light)
    if (res1 == parms.integrity or res2 == parms.integrity):
        result_out = result
    else:
        result_out = {'status':'error: Wrong integrity value'}
    return result_out

def _getMyResult(parms, result):
    if (result == {'status':'light'}):
        result_out = _calculateResult(parms, result)
    elif (result == {'status':'dark'}):
        result_out = _calculateResult(parms, result)
    elif (result == {'status':'ok'} or result == {'status':'end'}):
        result_out = _calculateResult(parms, result)
    return result_out

def _updatingResult(parms):
    if not isinstance(parms, Parameter):
        parms = Parameter(**parms)
    result = _statusCheck(parms)
    result_out = _getMyResult(parms, result)        
    return result_out
#returns result
def _result(parms):
    if(parms == {}):
        result_out = {'status':'error: Nothing has been passed'} 
        return result_out    
    else:
        result_out = _updatingResult(parms)  
        return result_out
#return the final status                                                                        
def _status(parms):
    result = {'status': 'status stub'}
    if(parms != {}):
        parms, booli = _parmsCheck(parms) 
        if(booli == True):
            parms = Parameter(**parms)
        else:
            result = {'status':'error: There was something wrong with your parameters'} 
            return result 
    result = _result(parms)
    return result


