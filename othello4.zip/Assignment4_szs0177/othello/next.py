def _next(parms):
    result = {'status': 'next stub'}
    return result
