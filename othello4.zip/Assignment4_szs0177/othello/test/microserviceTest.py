'''
     Created on March 8 2020
    
    @author:    Suryansh Soni
'''

from unittest import TestCase
from urllib.parse import urlencode
import json 
import http.client


class othelloTest(TestCase):
    def setUp(self, parm = ""):
        self.nominalLight = 1
        self.nominalDark = 2
        self.nominalBlank = 0
        self.nominalSize = 8
        self.inputDictionary = {}
        self.errorValue = "error:"
        self.errorKey = "error"
        self.solutionKey = "create"
        self.PATH = '/othello?'
        self.PORT = 5000
        self.URL = 'localhost'
        self.status = "ok"

    def tearDown(self):
        self.inputDictionary = {}

    def setlight(self, light):
        self.inputDictionary["light"] = light

    def setdark(self, dark):
        self.inputDictionary["dark"] = dark

    def setblank(self, blank):
        self.inputDictionary["blank"] = blank
    
    def setsize(self, size):
        self.inputDictionary["size"] = size
        
    def setExtra(self, extra):
        self.inputDictionary["extra"] = extra

    def microservice(self, parm =""):
        '''Issue HTTP Get and return result, which will be JSON string'''
        try:
            theParm = urlencode(parm)
            theConnection = http.client.HTTPConnection(self.URL, self.PORT)
            theConnection.request("GET", self.PATH + theParm)
            theStringResponse = str(theConnection.getresponse().read(),"utf-8")
        except Exception as e:
            theStringResponse = "{'diagnostic': '" + str(e) + "'}"
        
        '''Convert JSON string to dictionary'''
        result = {}
        try:
            jsonString = theStringResponse.replace("'", "\"")
            unicodeDictionary = json.loads(jsonString)
            for element in unicodeDictionary:
                if(isinstance(unicodeDictionary[element],str)):
                    result[str(element)] = str(unicodeDictionary[element])
                else:
                    result[str(element)] = unicodeDictionary[element]
        except Exception as e:
            result['diagnostic'] = str(e)
        return result
    
    
    
    #splits the url
    def returnParamters(self, a, parms):
        i = 1
        while i <= len(a) - 1:
            a_split = a[i].split('=')
            parms[a_split[0]] = a_split[1]
            i += 1
        parms['op'] = 'create'  
    
    def returnParamters2(self, a, parms):
        i = 1
        while i <= len(a) - 1:
            a_split = a[i].split('=')
            parms[a_split[0]] = a_split[1]
            i += 1
        parms['op'] = 'status'      
        
       
    def test1(self):
        parms = {'light':'6','dark':'5','blank':'1','size':'10'}
        parms['op'] = 'create'
        result = self.microservice(parms)
        self.assertEqual(result,{'board': [1, 1, 1, 1, 1, 1, 1,
                                           1, 1, 1, 1, 1, 1, 1, 
                                           1, 1, 1, 1, 1, 1, 1, 
                                           1, 1, 1, 1, 1, 1, 1, 
                                           1, 1, 1, 1, 1, 1, 1, 
                                           1, 1, 1, 1, 1, 1, 1, 
                                           1, 1, 6, 5, 1, 1, 1, 
                                           1, 1, 1, 1, 1, 5, 6, 
                                           1, 1, 1, 1, 1, 1, 1, 
                                           1, 1, 1, 1, 1, 1, 1, 
                                           1, 1, 1, 1, 1, 1, 1, 
                                           1, 1, 1, 1, 1, 1, 1, 
                                           1, 1, 1, 1, 1, 1, 1, 
                                           1, 1, 1, 1, 1, 1, 1, 1, 1],
                                  'tokens': {'light': 6, 'dark': 5, 'blank': 1}, 
                                  'status': 'ok', 
                                  'integrity': 'd0f18c5b412ab1dbf89da19baa33cc35f4a7dd0619ce7b7dcb2381d2cb14a412'})    

    def test2(self):
        string = "http://localhost:5000/othello?op=create&light=9&dark=5&blank=1&size=10"
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'board': [1, 1, 1, 1, 1, 1, 1, 1, 1, 
                                           1, 1, 1, 1, 1, 1, 1, 1, 1,
                                            1, 1, 1, 1, 1, 1, 1, 1, 1,
                                             1, 1, 1, 1, 1, 1, 1, 1, 1, 
                                             1, 1, 1, 1, 1, 1, 1, 1, 9, 
                                             5, 1, 1, 1, 1, 1, 1, 1, 1, 
                                             5, 9, 1, 1, 1, 1, 1, 1, 1,
                                              1, 1, 1, 1, 1, 1, 1, 1, 1,
                                               1, 1, 1, 1, 1, 1, 1, 1, 1, 
                                               1, 1, 1, 1, 1, 1, 1, 1, 1, 
                                               1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
                                            'tokens': {'light': 9, 'dark': 5, 'blank': 1},
                                             'status': 'ok', 
                                             'integrity': '723c769319c6529cf8520336232a9e5d281be77df1455c6ceb10a5d1d4733236'})    
      
        
    def test3(self):
        string = "http://localhost:5000/othello?op=create&light=0&dark=5&blank=1&size=10"
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'board': [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 
                                           1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
                                            1, 1, 1, 1, 1, 1, 0, 5, 1, 1, 1, 1, 1, 1, 1, 1, 5, 0, 1, 
                                            1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 
                                            1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 
                                            1, 1, 1, 1, 1],
                                            'tokens': {'light': 0, 'dark': 5, 'blank': 1},
                                            'status': 'ok',
                                            'integrity': '4bd2efa7e0d5f13551f7277950e45b6fcfe7d5159b80823a5dcbdf57abb4d83a'})

        
        
    def test4(self):
        string = "http://localhost:5000/othello?op=create&dark=5&blank=3&size=10"
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'board': [3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
                                           3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
                                           3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1, 5, 3, 3, 3, 3, 3, 
                                           3, 3, 3, 5, 1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
                                            3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
                                            3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3],
                                            'tokens': {'light': 1, 'dark': 5, 'blank': 3},
                                            'status': 'ok',
                                            'integrity': 'f211a92f576794a821bb24f359739b8b42a6a16634005a1e4b32313a6575e2be'})
    
    
    def test5(self):
        string = "http://localhost:5000/othello?op=create&dark=5&blank=3&size=10"
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'board': [3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
                                            3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
                                             3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1, 
                                             5, 3, 3, 3, 3, 3, 3, 3, 3, 5, 1, 3, 3, 3, 3, 
                                             3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
                                             3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
                                             3, 3, 3, 3, 3, 3, 3, 3, 3, 3], 
                                           'tokens': {'light': 1, 'dark': 5, 'blank': 3},
                                           'status': 'ok',
                                            'integrity': 'f211a92f576794a821bb24f359739b8b42a6a16634005a1e4b32313a6575e2be'})
    
    def test6(self):
        string = "http://localhost:5000/othello?op=create&light=3&dark=9&blank=4&size=10"
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'board': [4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 
                                           4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4,
                                            4, 4, 4, 4, 4, 4, 4, 4, 3, 9, 4, 4, 4, 4, 4, 4, 4, 4,
                                             9, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4,
                                              4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4,
                                               4, 4, 4, 4, 4, 4, 4, 4, 4, 4],
                                            'tokens': {'light': 3, 'dark': 9, 'blank': 4},
                                             'status': 'ok',
                                              'integrity': 'a3718ffbc2f822320ee4db10c269a9749859b9952db13ff6b289a6ebd6ce42c6'})
    
    def test7(self):
        string = "http://localhost:5000/othello?op=create&light=3&dark=0&blank=4&size=10"
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'board': [4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4,
                                            4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4,
                                             4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 3, 0, 4, 4, 4, 4, 4,
                                              4, 4, 4, 0, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 
                                              4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 
                                              4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4],
                                            'tokens': {'light': 3, 'dark': 0, 'blank': 4},
                                             'status': 'ok', 'integrity': '7bf98e8385a158097f52361dac139bb5882f3eaa48e8146d72d65de5981d2e5e'})                         
        
    def test8(self):
        string = "http://localhost:5000/othello?op=create&light=3&dark=4&blank=9&size=10"
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'board': [9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 
                                           9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9,
                                            9, 9, 9, 9, 9, 9, 9, 9, 3, 4, 9, 9, 9, 9, 9, 9, 9, 9,
                                             4, 3, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9,
                                              9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9,
                                               9, 9, 9, 9, 9, 9, 9, 9, 9, 9],
                                            'tokens': {'light': 3, 'dark': 4, 'blank': 9},
                                             'status': 'ok',
                                              'integrity': '5b4c82af0cf6a72ab1938b8e5a3c1ce413b9db583d0f974703954427413021d0'})
    
    def test9(self):
        string = "localhost:5000/othello?op=create&light=3&dark=4&blank=0&size=10"
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'board': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                             0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3,
                                              4, 0, 0, 0, 0, 0, 0, 0, 0, 4, 3, 0, 0, 0, 0,
                                               0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                                 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                                            'tokens': {'light': 3, 'dark': 4, 'blank': 0},
                                             'status': 'ok',
                                              'integrity': 'eeaa1d4229234a1453901319e7f584a337595d6d332a22a76c4aae8888cde9d6'})
      
    def test10(self):
        string = "localhost:5000/othello?op=create&light=3&dark=4&size=10"
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'board': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                             0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 4, 0, 0, 0, 0, 0,
                                              0, 0, 0, 4, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                                              0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                               0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                                            'tokens': {'light': 3, 'dark': 4, 'blank': 0},
                                             'status': 'ok',
                                              'integrity': 'eeaa1d4229234a1453901319e7f584a337595d6d332a22a76c4aae8888cde9d6'})    
        
    def test11(self):
        string = "http://localhost:5000/othello?op=create&light=3&dark=4&blank=5&size=16"
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'board': [5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                                            5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                                             5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                                              5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                                               5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                                                5, 5, 5, 5, 5, 5, 5, 5, 5, 3, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                                                 5, 5, 5, 4, 3, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 
                                                 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                                                  5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                                                   5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                                                    5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                                                     5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5],
                                            'tokens': {'light': 3, 'dark': 4, 'blank': 5},
                                             'status': 'ok',
                                              'integrity': '682b1bac788017f23b846862ce44f2c3efe03a22f49de36085e0e57fc6957416'})
        
    def test12(self):
        string = "http://localhost:5000/othello?op=create&light=3&dark=4&blank=5&size=6"
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'board': [5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 3, 4, 5, 5, 5, 5,
                                            4, 3, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5],
                                            'tokens': {'light': 3, 'dark': 4, 'blank': 5},
                                             'status': 'ok', 'integrity': 'b87b212e557d1dc1080f1c6e380bab404ae8cffa048b86e649e54c620f0d9c6a'}) 
    
    def test13(self):
        string = "http://localhost:5000/othello?op=create&light=3&dark=4&blank=5"
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result, {'board': [5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                                             5, 5, 5, 5, 5, 3, 4, 5, 5, 5, 5, 5, 5, 4, 3, 5, 5, 5, 5, 5, 5, 5, 
                                             5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5],
                                             'tokens': {'light': 3, 'dark': 4, 'blank': 5},
                                              'status': 'ok',
                                               'integrity': '306a2474c8f8b41c9e31af0fe360f9fcaf3531b3b4a1c3624acd8fbc2530b02e'})
        
    def test14(self):
        string = "http://localhost:5000/othello?op=create"
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'board': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                            0, 1, 2, 0, 0, 0, 0, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                             0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
                                           'tokens': {'light': 1, 'dark': 2, 'blank': 0}, 
                                           'status': 'ok', 
                                           'integrity': 'b11fcf5f9ac9d3b8cea8085208e210182a8d6b73a84028562ab2c87d190b9ada'})        
            
    def test15(self):
        string = "http://localhost:5000/othello?op=create&extra=1234"
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'board': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                            0, 0, 0, 0, 1, 2, 0, 0, 0, 0, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                             0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                                            'tokens': {'light': 1, 'dark': 2, 'blank': 0},
                                             'status': 'ok',
                                              'integrity': 'b11fcf5f9ac9d3b8cea8085208e210182a8d6b73a84028562ab2c87d190b9ada'})
        
    
    def test16(self):
        string = "http://localhost:5000/othello?op=create&light=10"
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: not in range'})
    
    def test17(self):
        string = "http://localhost:5000/othello?op=create&light=-1"
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: not in range'})  
    
    def test18(self):
        string = "http://localhost:5000/othello?op=create&light=w"
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: not in range'})  
    
    def test19(self):
        string = "http://localhost:5000/othello?op=create&light="
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: not in range'})
    
    def test20(self):
        string = "http://localhost:5000/othello?op=create&dark=10"
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: not in range'})
        
    def test21(self):
        string = "http://localhost:5000/othello?op=create&dark=-1"
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: not in range'})    
     
    def test22(self):
        string = "http://localhost:5000/othello?op=create&dark=d"
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: not in range'})
     
    def test23(self):
        string = "http://localhost:5000/othello?op=create&dark="
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: not in range'})
        
    def test24(self):
        string = "http://localhost:5000/othello?op=create&blank=10"
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: not in range'})
    
    def test25(self):
        string = "http://localhost:5000/othello?op=create&blank=-1"
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: not in range'})
    
    def test26(self):
        string = "http://localhost:5000/othello?op=create&blank=b"
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: not in range'})
    
    def test27(self):
        string = "http://localhost:5000/othello?op=create&blank="
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: not in range'})
    
    def test28(self):
        string = "http://localhost:5000/othello?op=create&size=17"
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error:board value not valid'})
    
    def test29(self):
        string = "http://localhost:5000/othello?op=create&size=5"
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error:board value not valid'})
     
    def test30(self):
        string = "http://localhost:5000/othello?op=create&blank=9"
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'board': [9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 1, 2, 9, 9, 9, 9, 9, 9, 2, 1, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9], 'tokens': {'light': 1, 'dark': 2, 'blank': 9}, 'status': 'ok', 'integrity': '33b9e6b1320bc82691ac373b95146531ce7e3ebbab318d2463a03c5c82ef9338'})
    
    def test31(self):
        string = "http://localhost:5000/othello?op=create&size=1.2"
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error:board value not valid'})
    
    def test32(self):
        string = "http://localhost:5000/othello?op=create&size="
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: not in range'})
    def test33(self):
        string = "http://localhost:5000/othello?op=create&light=5&dark=5&blank=0"
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: same parameters passed'})
        
    def test34(self):
        string = "http://localhost:5000/othello?op=create&light=5&dark=2&blank=5"
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: same parameters passed'})  
    
    def test35(self):
        string = "http://localhost:5000/othello?op=create&light=1&dark=2&blank=2"
        a = string.split('&')
        parms={}
        self.returnParamters(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: same parameters passed'}) 
    
    
    
    #status test 
    
    def test36(self):
        string = "http://localhost:5000/othello?op=status&light=1&dark=2&blank=0&board=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,0,0,0,0,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0]&integrity=6c3ec0129f5e128f48e2541bd6663a52a825c35f99b9a69d9593f2fc44b0bb4b"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'ok'}) 
        
    def test37(self):
        string = "http://localhost:5000/othello?op=status&light=9&dark=2&blank=0&board=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,2,0,0,0,0,2,9,0,0,0,0,0,0,0,0,0,0,0,0,0,0]&integrity=5ab81cb67067273363db989119448a0b878896f7db5c268a50c4ae3062cb3647"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'ok'}) 
        
    def test38(self):
        string = "http://localhost:5000/othello?op=status&light=0&dark=2&blank=1&board=[1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,2,1,1,1,1,2,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1]&integrity=1b7e612b959852acbaf6b55d3f6b8dab2cdc32248a58a89dcf022ae80e5b36de"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'ok'}) 
        
    def test39(self):
        string = "http://localhost:5000/othello?op=status&dark=2&blank=3&board=[3,3,3,3,3,3,3,3,3,3,3,3,3,3,1,2,3,3,3,3,2,1,3,3,3,3,3,3,3,3,3,3,3,3,3,3]&integrity=f01977c17f801c43eeb13fb9f74a49bd0c761db3cdffe01510f47ddd23ab465a"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'ok'})
        
    def test40(self):
        string = "http://localhost:5000/othello?op=status&light=5&dark=0&blank=9&board=[9,9,9,9,9,9,9,9,9,9,9,9,9,9,5,0,9,9,9,9,0,5,9,9,9,9,9,9,9,9,9,9,9,9,9,9]&integrity=85c972c79b667135f99ad9380f4af4a7495c5b5de3768c9cb36c4bc73f0da08a"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'ok'})
     
    def test41(self):
        string = "http://localhost:5000/othello?op=status&light=5&dark=9&blank=3&board=[3,3,3,3,3,3,3,3,3,3,3,3,3,3,5,9,3,3,3,3,9,5,3,3,3,3,3,3,3,3,3,3,3,3,3,3]&integrity=34932b7f4bbafed18cf99e367e29407e6aae8b49b2ced711f31e429e7efc2a12"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'ok'})   
    
    def test42(self):
        string = "http://localhost:5000/othello?op=status&light=5&blank=3&board=[3,3,3,3,3,3,3,3,3,3,3,3,3,3,5,2,3,3,3,3,2,5,3,3,3,3,3,3,3,3,3,3,3,3,3,3]&integrity=a348c2dae89e65378fc64d889b1d394819c021b2e4cccb37310bbef9335bb900"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'ok'})                  
            
    def test43(self):
        string = "http://localhost:5000/othello?op=status&light=5&dark=9&blank=3&board=[3,3,3,3,3,3,3,3,3,3,3,3,3,3,5,9,3,3,3,3,9,5,3,3,3,3,3,3,3,3,3,3,3,3,3,3]&integrity=34932b7f4bbafed18cf99e367e29407e6aae8b49b2ced711f31e429e7efc2a12"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'ok'})                  
    def test44(self):
        string = "http://localhost:5000/othello?op=status&light=5&blank=3&board=[3,3,3,3,3,3,3,3,3,3,3,3,3,3,5,2,3,3,3,3,2,5,3,3,3,3,3,3,3,3,3,3,3,3,3,3]&integrity=a348c2dae89e65378fc64d889b1d394819c021b2e4cccb37310bbef9335bb900"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'ok'})                  
            
    def test45(self):
        string = "http://localhost:5000/othello?op=status&light=5&dark=6&blank=0&board=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,5,6,0,0,0,0,6,5,0,0,0,0,0,0,0,0,0,0,0,0,0,0]&integrity=062f219e852404144cd7967bcbac5d5d82c151697d8eacfd8c29779acbc58b19"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'ok'})                  
    
    def test46(self):
        string = "http://localhost:5000/othello?op=status&light=5&dark=6&blank=9&board=[9,9,9,9,9,9,9,9,9,9,9,9,9,9,5,6,9,9,9,9,6,5,9,9,9,9,9,9,9,9,9,9,9,9,9,9]&integrity=5b698f38d9d1c1754df196ee688f3900ceba9d074cb74b5e17c19a197b69bf02"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'ok'})                  
            
    def test47(self):
        string = "http://localhost:5000/othello?op=status&light=5&dark=6&board=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,5,6,0,0,0,0,6,5,0,0,0,0,0,0,0,0,0,0,0,0,0,0]&integrity=062f219e852404144cd7967bcbac5d5d82c151697d8eacfd8c29779acbc58b19"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'ok'})                  
            
    def test48(self):
        string = "http://localhost:5000/othello?op=status&light=1&dark=2&blank=0&board=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,0,0,0,0,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0]&integrity=6c3ec0129f5e128f48e2541bd6663a52a825c35f99b9a69d9593f2fc44b0bb4b"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'ok'})                  
    def test49(self):
        string = "http://localhost:5000/othello?op=status&light=1&dark=2&blank=0&board=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,   0,0,0,0,0,0,0,1,2,0,0,0,0,0,0,0,   0,0,0,0,0,0,0,2,1,0,0,0,0,0,0,0,    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]&integrity=5df1fd1ccbd0dc74d65ab00d4d62f2e21c2def95dc47e7c73751986cdb5e8710"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'ok'})                  
    def test50(self):
        string = "http://localhost:5000/othello?op=status&light=1&dark=2&blank=3&board=[3,3,3,3,3,3,3,3,3,3,3,3,3,3,1,2,3,3,3,3,2,1,3,3,3,3,3,3,3,3,3,3,3,3,3,3]&integrity=f01977c17f801c43eeb13fb9f74a49bd0c761db3cdffe01510f47ddd23ab465a"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'ok'})                  
    def test51(self):
        string = "http://localhost:5000/othello?op=status&light=1&dark=2&blank=3&board=[3,3,3,3,3,3,3,3,3,3,3,3,3,3,1,2,3,3,3,3,2,2,2,3,3,3,3,3,3,3,3,3,3,3,3,3]&integrity=66271cbb9037c515e73be3a74a37259a179f2d2861cf4e82130cd579a2141093"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'ok'})                  
    def test52(self):
        string = "http://localhost:5000/othello?op=status&light=5&dark=9&blank=3&board=[3,3,3,3,3,3,3,3,3,3,3,3,3,3,5,9,3,3,3,3,9,5,3,3,3,3,3,3,3,3,3,3,3,3,3,3]&integrity=34932b7f4bbafed18cf99e367e29407e6aae8b49b2ced711f31e429e7efc2a12"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'ok'})                  
    def test53(self):
        string = "http://localhost:5000/othello?op=status&light=1&dark=2&blank=0&board=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,0,0,0,0,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0]&integrity=6c3ec0129f5e128f48e2541bd6663a52a825c35f99b9a69d9593f2fc44b0bb4b"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'ok'})  
        
                        
    def test54(self):
        string = "http://localhost:5000/othello?op=status&light=1&dark=2&blank=0&board=[0,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,0,1,1,1,1,0]&integrity=e2f7b8593ebadc126833074a7d8653d3c12c36ab3b7622a9cc6ac5dc1a0d9698"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'dark'})                  
    def test55(self):
        string = "http://localhost:5000/othello?op=status&light=1&dark=2&blank=3&board=[2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,3]&integrity=7c53df9ff782bbbff544d876f4d69a1d87d5864295c0e4a6bf29e6a7ee5a96fc"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'light'})                  
    def test56(self):
        string = "http://localhost:5000/othello?op=status&light=1&dark=2&blank=0&board=[1,1,1,1,1,1,1,1, 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0, 1,1,1,1,1,1,0,0,1,1,1,1,1,1,0,2,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1]&integrity=8a1c0659575e8cdd01b2e4ff3f431c845e7e7960279bb7abfaa5465e4a755354"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'end'})                  
    def test57(self):
        string = "http://localhost:5000/othello?op=status&light=10&dark=2&blank=1&board=[1,1,1,1,1,1,1,1,1,1,1,1,1,1,10,2,1,1,1,1,2,10,1,1,1,1,1,1,1,1,1,1,1,1,1,1]&integrity=b71bf3bee30fb8c3caa49752bcf9656870cfbd3bec4e4353e1e491054bf11c2f"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: There was something wrong with your parameters'})                  
    def test58(self):
        string = "http://localhost:5000/othello?op=status&light=-1&dark=2&blank=1&board=[1,1,1,1,1,1,1,1,1,1,1,1,1,1,-1,2,1,1,1,1,2,-1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]&integrity=f31631fdc7ba5ecd3096a306dbc7e43a9bc13fa781b91d83c36057f5050a51da"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: There was something wrong with your parameters'})                  
    def test59(self):
        string = "http://localhost:5000/othello?op=status&light=X&dark=2&blank=1&board=[1,1,1,1,1,1,1,1,1,1,1,1,1,1,X,2,1,1,1,1,2,X,1,1,1,1,1,1,1,1,1,1,1,1,1,1]&integrity=8959fc376b23af1520014ef3bef1eb4f924ec692bbbcd9f638245bf85fb0a6da"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: There was something wrong with your parameters'})                  
    def test60(self):
        string = "http://localhost:5000/othello?op=status&light=&dark=2&blank=1&board=[1,1,1,1,1,1,1,1,1,1,1,1,1,1,3,2,1,1,1,1,2,3,1,1,1,1,1,1,1,1,1,1,1,1,1,1]&integrity= 1cc0050055aa122edbb536cc63dfe515e6a55132a42a6c8fa41349ab6e572c6a"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: There was something wrong with your parameters'})                  
    def test61(self):
        string = "http://localhost:5000/othello?op=status&light=5&dark=10&blank=1&board=[1,1,1,1,1,1,1,1,1,1,1,1,1,1,5,10,1,1,1,1,10,5,1,1,1,1,1,1,1,1,1,1,1,1,1,1]&integrity=e8a244c301df58429d82070942fe05dff389162c0aeec8383e3c82863ae09c62"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: There was something wrong with your parameters'})                  
    def test62(self):
        string = "http://localhost:5000/othello?op=status&light=5&dark=-1&blank=1&board=[1,1,1,1,1,1,1,1,1,1,1,1,1,1,5,-1,1,1,1,1,-1,5,1,1,1,1,1,1,1,1,1,1,1,1,1,1]&integrity=301e0f00c1b83b65adc1d4fd5e87aaf7f594aa20842ab1df86a6be2e144367db"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: There was something wrong with your parameters'})                  
    def test63(self):
        string = "http://localhost:5000/othello?op=status&light=5&dark=1.2&blank=1&board=[1,1,1,1,1,1,1,1,1,1,1,1,1,1,5,1.2,1,1,1,1,1.2,5,1,1,1,1,1,1,1,1,1,1,1,1,1,1]&integrity=e62a2ec6eb082391a6a5664b4f4dbd8130e43d6589267b19b831423bfcde4a9d"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: There was something wrong with your parameters'})                  
    def test64(self):
        string = "http://localhost:5000/othello?op=status&light=1&dark=&blank=3&board=[3,3,3,3,3,3,3,3,3,3,3,3,3,3,1,2,3,3,3,3,2,1,3,3,3,3,3,3,3,3,3,3,3,3,3,3]&integrity=5d5aeb4a45b57eecf69dcc304664fcf7a6f7c74c86ef9ede14da46ab2d9df242"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: There was something wrong with your parameters'})                  
    def test65(self):
        string = "http://localhost:5000/othello?op=status&light=5&dark=9&blank=3&board=[3,3,3,3,3,3,3,3,3,3,3,3,3,3,5,9,3,3,3,3,9,5,3,3,3,3,3,3,3,3,3,3,3,3,3,3]&integrity=34932b7f4bbafed18cf99e367e29407e6aae8b49b2ced711f31e429e7efc2a12"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'ok'})                  
    def test66(self):
        string = "http://localhost:5000/othello?op=status&light=1&dark=2&blank=10&board=[10,10,10,10,10,10,10,10,10,10,10,10,10,10,1,2,10,10,10,10,2,1,10,10,10,10,10,10,10,10,10,10,10,10,10,10]&integrity=530242aec98aa07d3c025b9101bd5b840527cd9b03302641da18c801d70c37e8"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: There was something wrong with your parameters'})                  
    def test67(self):
        string = "http://localhost:5000/othello?op=status&light=1&dark=2&blank=-1&board=[-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,1,2,-1,-1,-1,-1,2,1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1]&integrity=2e226315d3fc18cf5771b45ae78bfe7be9510ee98b6e566e382f8a70861c8e7d"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: There was something wrong with your parameters'})                  
    def test68(self):
        string = "http://localhost:5000/othello?op=status&light=1&dark=2&blank=1E5&board=[1E5,1E5,1E5,1E5,1E5,1E5,1E5,1E5,1E5,1E5,1E5,1E5,1E5,1E5,1,2,1E5,1E5,1E5,1E5,2,1,1E5,1E5,1E5,1E5,1E5,1E5,1E5,1E5,1E5,1E5,1E5,1E5,1E5,1E5]&integrity=fe62b7f99befb02e21c50cc755a68ef80fb59d56224b02a1f2888e0830454773"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: There was something wrong with your parameters'})                  
    def test69(self):
        string = "http://localhost:5000/othello?op=status&light=1&dark=2&blank=&board=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,0,0,0,0,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0]&integrity=6c3ec0129f5e128f48e2541bd6663a52a825c35f99b9a69d9593f2fc44b0bb4b"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: There was something wrong with your parameters'})                  
    def test70(self):
        string = "http://localhost:5000/othello?op=status&light=1&dark=2&blank=3&board=[3,3,3,3,3,3,3,3,3,3,3,3,3,3,1,2,3,3,3,3,2,1,3,3,3,3,3,3,3,3,3,3,3,3,3]&integrity=9d43a04297202bccc81a13b6857179269c0fe33e5227c6569286d54d82493ba6"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: There was something wrong with your parameters'})                  
    def test71(self):
        string = "http://localhost:5000/othello?op=status&light=1&dark=2&blank=3&board=[3,3,3,3,3,3,3,3,3,3,3,3,3,3,1,2,3,3,3,3,2,1,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3]&integrity=1e3f8bb2d56c5b4483c9f3dccf7bc16d339534a98020e9a28383aaa219f3e64d"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: There was something wrong with your parameters'})                  
    def test72(self):
        string = "http://localhost:5000/othello?op=status&light=1&dark=2&blank=3&integrity=1e3f8bb2d56c5b4483c9f3dccf7bc16d339534a98020e9a28383aaa219f3e64d"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: There was something wrong with your parameters'})                  
    def test73(self):
        string = "http://localhost:5000/othello?op=status&light=1&dark=2&blank=3&board=&integrity=1e3f8bb2d56c5b4483c9f3dccf7bc16d339534a98020e9a28383aaa219f3e64d"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: There was something wrong with your parameters'})                  
    def test74(self):
        string = "http://localhost:5000/othello?op=status&light=1&dark=2&blank=3&board=[3,3,3,3,3,3,3,3,3,3,3,3,3,3,1,2,3,3,3,3,2,1,3,3,3,3,3,3,3,3,3,3,3,3,3,3]&integrity=f01977c17f801c43eeb13fb9f74a49bd0c761db3cdffe01510f47ddd23ab465"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: There was something wrong with your parameters'})                  
     
    def test75(self):
        string = "http://localhost:5000/othello?op=status&light=1&dark=2&blank=3&board=[3,3,3,3,3,3,3,3,3,3,3,3,3,3,1,2,3,3,3,3,2,1,3,3,3,3,3,3,3,3,3,3,3,3,3,3]&integrity=f01977c17f801c43eeb13fb9f74a49bd0c761db3cdffe01510f47ddd23ab465$"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: Wrong integrity value'})                  
    
    def test76(self):
        string = "http://localhost:5000/othello?op=status&light=1&dark=2&blank=3&board=[3,3,3,3,3,3,3,3,3,3,3,3,3,3,1,2,3,3,3,3,2,1,3,3,3,3,3,3,3,3,3,3,3,3,3,3]"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: There was something wrong with your parameters'})                  
            
    def test77(self):
        string = "http://localhost:5000/othello?op=status&light=1&dark=2&blank=3&board=[3,3,3,3,3,3,3,3,3,3,3,3,3,3,1,2,3,3,3,3,2,1,3,3,3,3,3,3,3,3,3,3,3,3,3,3]&integrity="
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: There was something wrong with your parameters'})
        
    def test78(self):
        string = "http://localhost:5000/othello?op=status&light=2&dark=2&blank=0&board=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,2,0,0,0,0,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0]&integrity=e50f93033edd2b27fd1c54631a4b574e545df9e8c06e0b4f74ca94841a4ab6c4"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: There was something wrong with your parameters'})
     
    def test79(self):
        string = "http://localhost:5000/othello?op=status&light=1&dark=2&blank=1&board=[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]&integrity=c725061d80e342070c231d2b987c476f92b8f3d9e5826c2223cff281562e8e2c"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: There was something wrong with your parameters'})
    def test80(self):
        string = "http://localhost:5000/othello?op=status&light=1&dark=2&blank=2&board=[2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,2,2,2,2,2,2,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2]&integrity=4edfe0aad5d491d98b8103e4f8f899cd3cef690f6ec3602a16e5a0e0301e8bd6"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: There was something wrong with your parameters'})
    
    def test81(self):
        string = "http://localhost:5000/othello?op=status&light=1&dark=2&blank=3&board=[3,3,3,3,3,3,3,3,3,3,3,3,3,3,1,2,3,3,3,3,2,1,3,3,3,3,3,3,3,3,3,3,3,3,3,3]&integrity=b42a70b9f5b1064d1a1c594f466ec6cb1c2383694a8fe9f660d7fb07bcdce637"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: Wrong integrity value'})
    
    def test82(self):
        string = "http://localhost:5000/othello?op=status&light=1&dark=2&blank=3&board=[3,3,3,3,3,3,3,3,3,3,3,3,3,3,1,2,3,3,3,3,2,1,3,3,3,3,3,3,3,3,3,3,3,3,3,3]&integrity=4d5aeb4a45b57eecf69dcc304664fcf7a6f7c74c86ef9ede14da46ab2d9df242"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: Wrong integrity value'})
    def test83(self):
        string = "http://localhost:5000/othello?op=status&light=1&dark=2&blank=3&board=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,0,0,0,0,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0]&integrity=c9fd7c0049f79f33e45998064cd1fca01600dd5cdc55cb3bf33169cd07c1905a"
        a = string.split('&')
        parms={}
        self.returnParamters2(a, parms)
        result = self.microservice(parms)
        self.assertEqual(result,{'status': 'error: There was something wrong with your parameters'})
        
      
        
                                                
                                                                                                                                                                                                                                                                                                    
              
        