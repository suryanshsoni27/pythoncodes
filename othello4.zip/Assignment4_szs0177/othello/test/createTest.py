'''
     Created on March 8 2020
    
    @author:    Suryansh Soni
'''

from unittest import TestCase
from othello.create import _create


class CreateTest(TestCase):        
    def test1_othello(self):
        parms = {'light':'1','dark':'2','blank':'0','size':'8'}
        result = _create(parms)
        self.assertEqual(result['board'],[0,0,0,0,0,0,0,0,
                                          0,0,0,0,0,0,0,0,
                                          0,0,0,0,0,0,0,0, 
                                          0,0,0,1,2,0,0,0, 
                                          0,0,0,2,1,0,0,0, 
                                          0,0,0,0,0,0,0,0, 
                                          0,0,0,0,0,0,0,0,
                                          0,0,0,0,0,0,0,0])
    def test2_othello(self):
        parms = {'light':'2','dark':'3','blank':'0','size':'8'}
        result = _create(parms)
        self.assertEqual(result['tokens'], {'light': 2,'dark': 3, 'blank': 0})
        
        
      
    def test3_othello(self):
        parms = {'light':'2','dark':'3','blank':'0','size':'8'}
        result = _create(parms)
        self.assertEqual(result['status'],'ok')    
        
    def test4_othello(self):
        parms = {'light':'2','dark':'3','blank':'0','size':'8'}
        result = _create(parms)
        self.assertEqual(result['board'],[0,0,0,0,0,0,0,0,
                                          0,0,0,0,0,0,0,0,
                                          0,0,0,0,0,0,0,0, 
                                          0,0,0,2,3,0,0,0, 
                                          0,0,0,3,2,0,0,0, 
                                          0,0,0,0,0,0,0,0, 
                                          0,0,0,0,0,0,0,0,
                                          0,0,0,0,0,0,0,0]) 
    def test5_othello(self):
        parms = {'light':'3','dark':'4','blank':'0','size':'8'}
        result = _create(parms)
        self.assertEqual(result['board'],[0,0,0,0,0,0,0,0,
                                          0,0,0,0,0,0,0,0,
                                          0,0,0,0,0,0,0,0, 
                                          0,0,0,3,4,0,0,0, 
                                          0,0,0,4,3,0,0,0, 
                                          0,0,0,0,0,0,0,0, 
                                          0,0,0,0,0,0,0,0,
                                          0,0,0,0,0,0,0,0])             
    
    def test6_othello(self):
        parms = {'light':'3','dark':'4','blank':'0','size':'6'}
        result = _create(parms)
        self.assertEqual(result['board'],[0,0,0,0,0,0,  0,0,0,0,0,0, 0,0,3,4,0,0, 0,0,4,3,0,0, 0,0,0,0,0,0, 0,0,0,0,0,0])    
        
        
        
    def test7_othello(self):
        parms = {'light':'3','dark':'4','blank':'0','size':'10'}
        result = _create(parms)  
        self.assertEqual(result['board'],[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                                          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                                          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                                          0, 0, 0, 0, 0, 0, 0, 0, 3, 4, 0, 0, 
                                          0, 0, 0, 0, 0, 0, 4, 3, 0, 0, 0, 0, 
                                          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                                          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                                          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                                          0, 0, 0, 0])
        
    def test801_othello(self):
        parms = {'light':'11','dark':'12','blank':'22','size':'10'}
        result = _create(parms)
        self.assertEqual(result,{'status':'error: not in range'})    
     
    def test803_othello(self):
        parms = {'light':None,'dark':'4','blank':'0','size':'6'}
        result = _create(parms)
        self.assertEqual(result,{'status':'error: not in range'})  
        
    def test12_othello(self):
        parms = {'light':'1','dark':'2','blank':'0','size':'8'}
        result = _create(parms)
        self.assertEqual(result['integrity'],'b11fcf5f9ac9d3b8cea8085208e210182a8d6b73a84028562ab2c87d190b9ada')  
        
    def test13_othello(self):
        parms = {'light':'1','dark':'2','blank':'0','size':'6'}
        result = _create(parms)
        self.assertEqual(result['integrity'],'6c3ec0129f5e128f48e2541bd6663a52a825c35f99b9a69d9593f2fc44b0bb4b')
        
        
    def test14_othello(self):
        parms = {'light':'3','dark':'4','blank':None,'size':'10'}
        result = _create(parms)
        self.assertEqual(result,{'status':'error: not in range'})
        
    def test15_othello(self):
        parms = {'light':'3','dark':'4','blank':'5','size':'6'}
        result = _create(parms)
        self.assertEqual(result,{'board': [5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 3, 4, 5, 5, 5, 5, 4, 3, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5], 'tokens': {'light': 3, 'dark': 4, 'blank': 5}, 'status': 'ok', 'integrity': 'b87b212e557d1dc1080f1c6e380bab404ae8cffa048b86e649e54c620f0d9c6a'})
    
    def test16_othello(self):
        parms = {}
        result = _create(parms)
        self.assertEqual(result,{'board': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 0, 0, 0, 0, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 'tokens': {'light': 1, 'dark': 2, 'blank': 0}, 'status': 'ok', 'integrity': 'b11fcf5f9ac9d3b8cea8085208e210182a8d6b73a84028562ab2c87d190b9ada'})               
   
    def test17_othello(self):
        parms = {'light':'1','dark':'2','blank':'0','size':'9'}
        result = _create(parms)
        self.assertEqual(result,{'status':'error:board value not valid'})
        
    def test18_othello(self):
        parms = {'extra':'1234'}
        result = _create(parms)
        self.assertEqual(result['status'],'ok')   
    
    def test19_othello(self):
        parms = {'light':'2','dark':'2','blank':'0','size':'9'}
        result = _create(parms)
        self.assertEqual(result,{'status':'error: same parameters passed'})
    
    def test20_othello(self):
        parms = {'light':'w','dark':'w','blank':'w','size':'9'}
        result = _create(parms)
        self.assertEqual(result,{'status':'error: not in range'})      
        
    def test21_othello(self):
        parms = {'light':'1.2','dark':'1.3','blank':'1.6','size':'12.5'}
        result = _create(parms)
        self.assertEqual(result,{'status':'error: not in range'})     
    
    def test22_othello(self):
        parms = {'light':'-1','dark':'2','blank':'3','size':'8'}
        result = _create(parms)
        self.assertEqual(result,{'status':'error: not in range'})
        
    def test23_othello(self):
        parms = {'light':'1','dark':'2','blank':'3','size':'-12'}
        result = _create(parms)
        self.assertEqual(result,{'status':'error:board value not valid'}) 
    
    def test24_othello(self):
        parms = {'light':'1','dark':'','blank':'3','size':'12'}
        result = _create(parms)
        self.assertEqual(result,{'status':'error: not in range'})        
        
    def test2401_othello(self):
        parms = {'light':'1','dark':'8','blank':'10','size':'12'}
        result = _create(parms)
        self.assertEqual(result,{'status':'error: not in range'})   
        
    def test25_othello(self):
        parms = {'light':'1','dark':'8','blank':'w','size':'12'}
        result = _create(parms)
        self.assertEqual(result,{'status':'error: not in range'})      
   