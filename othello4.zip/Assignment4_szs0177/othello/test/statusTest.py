'''
     Created on March 21 2020
    
    @author:    Suryansh Soni
'''


from unittest import TestCase
import othello.status as st
from othello.status import _parmsCheck, _status

class StatusTest(TestCase):
    def test1_status(self):
        parms = {}
        result = st._status(parms)
        self.assertEqual(result,{'status':'error: Nothing has been passed'})
    
    def test2_status(self):
        parms = {'light':'1','dark':'2','blank':'0',
                 'board':'[0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,0,0,0,0,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0]',
                 'integrity':'6c3ec0129f5e128f48e2541bd6663a52a825c35f99b9a69d9593f2fc44b0bb4b'}
        parms = st.Parameter(**parms)
        self.assertEqual(1,int(parms.light))
        self.assertEqual(2,int(parms.dark))
        self.assertEqual(0,int(parms.blank))
              
    def test3_status(self):
        parms = {'light':'1','dark':'2','blank':'0',
                 'board':'[0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,0,0,0,0,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0]',
                 'integrity':'6c3ec0129f5e128f48e2541bd6663a52a825c35f99b9a69d9593f2fc44b0bb4b'}
         
        result = st._result(parms)
        self.assertEqual(result,{'status':'ok'})
        
        
        
    def test4_status(self):
        parms = {'light':'1','dark':'2','blank':'0',
                 'board':'[0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,0,0,0,0,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0]',
                 'integrity':'6c3ec0129f5e128f48e2541bd6663a52a825c35f99b9a69d9593f2fc44b0bb4b'}
         
        parms,result = st._parmsCheck(parms)
        self.assertEqual(result,True)    
        
    def test5_status(self):
        parms = {'light':'1','dark':'2','blank':'0',
                 'board':'[0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,0,0,0,0,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0]',
                 'integrity':'6c3ec0129f5e128f48e2541bd6663a52a825c35f99b9a69d9593f2fc44b0bb4b'}
        
        result = st._ischeckBoard_valid(parms)
        self.assertEqual(result,True)
                 
    def test8_status(self):
        parms = {'light':'1','dark':'2','blank':'0','board':'','integrity':'e2f7b8593ebadc126833074a7d8653d3c12c36ab3b7622a9cc6ac5dc1a0d9698'}
        parms, result = _parmsCheck(parms)
        self.assertEqual(result,False)             
            
    def test9_status(self):
        parms = {'light':'1','dark':'2','blank':'0','board':'[0,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,0,1,1,1,1,0]','integrity':''}
        result2 = _status(parms)
        self.assertEquals(result2,{'status':'error: There was something wrong with your parameters'})
        
    def test10_status(self):
        parms = {'light':'1','dark':'2','blank':'0',
            'board':'[0,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,0,1,1,1,1,0]','integrity':'e2f7b8593ebadc126833074a7d8653d3c12c36ab3b7622a9cc6ac5dc1a0d9698'}
        result= st._statusCheck(parms)
        self.assertEquals(result,{'status': 'dark'})
    
    def test11_status(self):
        parms = {'light':'1','dark':'2','blank':'0',
                 'board':'[0,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,0,1,1,1,1,0]','integrity':'e2f7b8593ebadc126833074a7d8653d3c12c36ab3b7622a9cc6ac5dc1a0d9698'}
        parms = st.Parameter(**parms)
        result= st._ispositionAvailable(parms.board,parms)
        self.assertEquals(result,([0,5,30,35]))    
        
    def test12_status(self):
        parms = {'light':'1','dark':'2','blank':'3',
                 'board':'[2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,3]','integrity':'7c53df9ff782bbbff544d876f4d69a1d87d5864295c0e4a6bf29e6a7ee5a96fc'}
        result= st._statusCheck(parms)
        self.assertEquals(result,{'status': 'light'})   
    
    def test13_status(self):
        parms = {'light':'1','dark':'2','blank':'0',
                 'board':'[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,0,0,1,1,1,1,1,1,0,2,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1]','integrity':'8a1c0659575e8cdd01b2e4ff3f431c845e7e7960279bb7abfaa5465e4a755354'}
        result= st._statusCheck(parms)
        self.assertEquals(result,{'status': 'end'}) 
    
    def test14_status(self):
        parms = {'light':'1','dark':'2','blank':'0',
                 'board':'[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]','integrity':'8a1c0659575e8cdd01b2e4ff3f431c845e7e7960279bb7abfaa5465e4a755354'}
        result= st._statusCheck(parms)
        self.assertEquals(result,{'status': 'ok'})
        
    def test15_status(self):
        parms = {'light':'1','dark':'2','blank':'3',
                 'board':'[3,3,3,3,3,3,3,3,3,3,3,3,3,3,1,2,3,3,3,3,2,1,3,3,3,3,3,3,3,3,3,3,3,3,3,3]','integrity':'f01977c17f801c43eeb13fb9f74a49bd0c761db3cdffe01510f47ddd23ab465a'}
        result= st._statusCheck(parms)
        self.assertEquals(result,{'status': 'ok'})
        
    def test16_status(self):
        parms = {'light':'1','dark':'2','blank':'3',
                 'board':'[3,3,3,3,3,3,3,3,3,3,3,3,3,3,1,2,3,3,3,3,2,1,3,3,3,3,3,3,3,3,3,3,3,3,3,3]','integrity':'f01977c17f801c43eeb13fb9f74a49bd0c761db3cdffe01510f47ddd23ab465a'}
        result= _status(parms)

        self.assertEquals(result,{'status': 'ok'}) 
        
    def test17_status(self):
        parms = {'light':'1','dark':'2','blank':'3',
                 'board':'[2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,3]','integrity':'7c53df9ff782bbbff544d876f4d69a1d87d5864295c0e4a6bf29e6a7ee5a96fc'}
        result= _status(parms)
        self.assertEquals(result,{'status': 'light'})
       
    def test18_status(self):
        parms = {'dark':'2','blank':'3',
                 'board':'[3,3,3,3,3,3,3,3,3,3,3,3,3,3,1,2,3,3,3,3,2,1,3,3,3,3,3,3,3,3,3,3,3,3,3,3]','integrity':'f01977c17f801c43eeb13fb9f74a49bd0c761db3cdffe01510f47ddd23ab465a'}
        result= _status(parms)
        self.assertEquals(result,{'status': 'ok'})   
        
    def test19_status(self):
        parms = {'light':'1','dark':'2','blank':'0',
            'board':'[0,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,0,1,1,1,1,0]','integrity':'e2f7b8593ebadc126833074a7d8653d3c12c36ab3b7622a9cc6ac5dc1a0d9698'}
        result= _status(parms)
        self.assertEquals(result,{'status': 'dark'}) 
    
    def test20_status(self):
        parms = {'light':'5','dark':'-1','blank':'1',
            'board':'[1,1,1,1,1,1,1,1,1,1,1,1,1,1,5,-1,1,1,1,1,-1,5,1,1,1,1,1,1,1,1,1,1,1,1,1,1]','integrity':'301e0f00c1b83b65adc1d4fd5e87aaf7f594aa20842ab1df86a6be2e144367db'}
        result= _status(parms)
        self.assertEquals(result,{'status':'error: There was something wrong with your parameters'})        
  
    def test21_status(self):
        parms = {'light':'X','dark':'2','blank':'1',
            'board':'[1,1,1,1,1,1,1,1,1,1,1,1,1,1,X,2,1,1,1,1,2,X,1,1,1,1,1,1,1,1,1,1,1,1,1,1]','integrity':'8959fc376b23af1520014ef3bef1eb4f924ec692bbbcd9f638245bf85fb0a6da'}
        result= _status(parms)
        self.assertEquals(result,{'status':'error: There was something wrong with your parameters'})
        
  
    def test22_status(self):
        parms = {'light':'1','dark':'2','blank':'0',
            'board':'[1,0,0,0,0,0,0,2,1,1,1,1,1,1,0,2,1,1,1,1,2,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1]','integrity':'8959fc376b23af1520014ef3bef1eb4f924ec692bbbcd9f638245bf85fb0a6da'}
        result= st._statusCheck(parms)
        self.assertEquals(result,{'status':'end'}) 
        
    
        
               
        
       
            
      
        
        
        
         