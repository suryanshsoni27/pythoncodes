'''
     Created on April 20 2020
    
    @author:  Suryansh Soni
'''


from unittest import TestCase
import othello.place as pl
from othello.place import _place, _ischeckLocationValid
import othello.status as st

class StatusTest(TestCase):
    def test1_place(self):
        
        parms = {}
        result = _place(parms)
        self.assertEqual(result,{'status':'error: Nothing has been passed'})
        
      
        
    def test3_place(self):
        parms = {'light':'1',
                  'dark':'2',
                  'blank':'0',
                 'board':'[0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,0,0,0,0,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0]',
                 'location':'1:1',
                 'integrity':'6c3ec0129f5e128f48e2541bd6663a52a825c35f99b9a69d9593f2fc44b0bb4b'} 
        result = pl._playNext(parms) 
        self.assertEqual(result,'1:1')
        
    def test4_place(self):
        parms = {'light':'1',
                  'dark':'2',
                  'blank':'0',
                 'board':'[0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,0,0,0,0,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0]',
                 'location':'1:1',
                 'integrity':'6c3ec0129f5e128f48e2541bd6663a52a825c35f99b9a69d9593f2fc44b0bb4b'} 
        result = pl._whatIsStatusofParm(parms)
        self.assertEqual(result,{'status':'ok'})    
    
    def test5_place(self):
        parms = {'light':'1',
                  'dark':'2',
                  'blank':'0',
                 'board':'[0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,0,0,0,0,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0]',
                 'location':'0:1',
                 'integrity':'6c3ec0129f5e128f48e2541bd6663a52a825c35f99b9a69d9593f2fc44b0bb4b'} 
        result = pl._placeOnBoard(parms)
        self.assertEqual(result,([0,2,0,0,0,0,0,0,0,0,0,0,0,0,1,2,0,0,0,0,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0],2))  
    
    def test6_place(self):
        parms = {'light':'1',
                  'dark':'2',
                  'blank':'0',
                 'board':'[0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,0,0,0,0,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0]',
                 'location':'1:1',
                 'integrity':'6c3ec0129f5e128f48e2541bd6663a52a825c35f99b9a69d9593f2fc44b0bb4b'} 
        result = _ischeckLocationValid(parms)
        self.assertEqual(result,True)   
        
    def test7_place(self):
        parms = {'light':'1',
                  'dark':'2',
                  'blank':'0',
                 'board':'[0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,0,0,0,0,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0]',
                 'location':'121:111',
                 'integrity':'6c3ec0129f5e128f48e2541bd6663a52a825c35f99b9a69d9593f2fc44b0bb4b'} 
        result = _ischeckLocationValid(parms)
        self.assertEqual(result,True) 
    
    def test8_place(self):
        parms = {'light':'1',
                  'dark':'2',
                  'blank':'0',
                 'board':'[0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,0,0,0,0,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0]',
                 'location':'0:0',
                 'integrity':'6c3ec0129f5e128f48e2541bd6663a52a825c35f99b9a69d9593f2fc44b0bb4b'} 
        result = pl._returnIntegirty(parms)
        self.assertEqual(result,'f077845a112b80054aa9306362ce55394bb85f60a8efef84addf6c2428da2993')              
     
    def test9_place(self):
        parms = {'light':'1',
                  'dark':'2',
                  'blank':'0',
                 'board':'[0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,0,0,0,0,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0]',
                 'location':'0:0',
                 'integrity':'6c3ec0129f5e128f48e2541bd6663a52a825c35f99b9a69d9593f2fc44b0bb4b'} 
        result = pl._statusUpdate(parms)
        self.assertEqual(result,'ok')  
        
    def test10_place(self):
        parms = {'light':'1',
                 'dark':'2',
                 'blank':'0',
                 'board':'[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,0,0,1,1,1,1,1,1,0,2,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1]',
                 'location':'0:0',
                 'integrity':'8a1c0659575e8cdd01b2e4ff3f431c845e7e7960279bb7abfaa5465e4a755354'}
        result1 = pl._statusUpdate(parms)
        result2 = pl._returnIntegirty(parms)
        self.assertEquals(result1,'end:58/1')
        self.assertEquals(result2,'8a1c0659575e8cdd01b2e4ff3f431c845e7e7960279bb7abfaa5465e4a755354')
        
    def test11_place(self):
        parms = {'light':'1',
                  'dark':'2',
                  'blank':'0',
                 'board':'[0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,0,0,0,0,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0]',
                 'location':'0:0',
                 'integrity':'6c3ec0129f5e128f48e2541bd6663a52a825c35f99b9a69d9593f2fc44b0bb4b'} 
        result = pl._combineStatusForPlace(parms)
        self.assertEqual(result,{'board':[2,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,0,0,0,0,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0],'integrity':'f077845a112b80054aa9306362ce55394bb85f60a8efef84addf6c2428da2993','status':'ok'})   
        
    def test12_place(self):
        parms = {'light':'1','dark':'2','blank':'3',
                 'board':'[2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,3]','location':'0:0','integrity':'7c53df9ff782bbbff544d876f4d69a1d87d5864295c0e4a6bf29e6a7ee5a96fc'}
        result= pl._seeNext(parms)
        result2 = pl._returnIntegirty(parms)
        self.assertEquals(result,{'status': 'light'}) 
        
    def testacceptace_place(self):
        parms = {'light':'1',
                  'dark':'2',
                  'blank':'0',
                 'board':'[0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,0,0,0,0,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0]',
                 'location':'0:0',
                 'integrity':'6c3ec0129f5e128f48e2541bd6663a52a825c35f99b9a69d9593f2fc44b0bb4b'} 
        result = pl._place(parms)
        self.assertEqual(result,{'board':[2,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,0,0,0,0,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0],'integrity':'f077845a112b80054aa9306362ce55394bb85f60a8efef84addf6c2428da2993','status':'ok'})       
    
    def test14_place(self):
        parms = {'light':'1',
                  'dark':'2',
                  'blank':'0',
                 'board':'[2,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,0,0,0,0,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0]',
                 'location':'0:0',
                 'integrity':'f077845a112b80054aa9306362ce55394bb85f60a8efef84addf6c2428da2993'} 
        result = pl._checkIfTokenALreaadyOnBoard(parms)
        self.assertEquals(result,{'status': 'error token already in that place try different location value'})
        
    
         