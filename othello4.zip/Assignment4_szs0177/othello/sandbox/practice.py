stri = "s"
print(str(stri))  
strii = str(stri)
print(type(strii))      




